let hours_worked = 6

