

let create_board dimension = 
  Array.make_matrix dimension dimension " - "
